# Deploy MERN APP with AWS EC2
