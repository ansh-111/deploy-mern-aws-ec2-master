export const LOGIN_USER = 'login_user';
export const REGISTER_USER = 'register_user';
export const AUTH_USER = 'auth_user';
export const LOGOUT_USER = 'logout_user';


export const SAVE_MESSAGE = 'save_message';


export const GET_CHATS = 'get_chats';
export const AFTER_POST_MESSAGE = 'after_post_message';